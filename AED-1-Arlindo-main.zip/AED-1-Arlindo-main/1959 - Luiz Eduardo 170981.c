/*Luiz eduardo garcia de Siqueira 170981 turma NA
AED 1 Prof. Arlindo - 2024.2*/

int main(){
	long long int n, l;
	scanf("%lld",&n);scanf("%lld",&l);
    printf("%lld\n",(n*l));
return 0;}
