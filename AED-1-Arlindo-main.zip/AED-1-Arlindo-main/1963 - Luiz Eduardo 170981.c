/*Luiz eduardo garcia de Siqueira 170981 turma NA
AED 1 Prof. Arlindo - 2024.2*/

#include <stdio.h>
int main(){
    double a,b;
        scanf("%lf",&a);scanf("%lf",&b);
    printf("%.2lf%%\n",(((b-a)/a)*100));
return 0;}
