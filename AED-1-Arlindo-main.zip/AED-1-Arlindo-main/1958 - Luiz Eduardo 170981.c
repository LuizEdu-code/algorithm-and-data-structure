/*Luiz eduardo garcia de Siqueira 170981 turma NA
AED 1 Prof. Arlindo - 2024.2*/

#include <stdio.h>
int main(){
	long double num;
    scanf("%LE",&num);
    printf("%+.4LE\n",num);
return 0;}
