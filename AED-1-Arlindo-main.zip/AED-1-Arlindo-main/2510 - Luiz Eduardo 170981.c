/*Luiz eduardo garcia de Siqueira 170981 turma NA
AED 1 Prof. Arlindo - 2024.2*/

#include <stdio.h>
#include <stdlib.h>
int main(){
    int t,i;
    char n[30];
        scanf("%d",&t);
    for (i=0;i<t;i++){
        scanf("%s",&n);
        printf("Y\n");
    }
return 0;}
