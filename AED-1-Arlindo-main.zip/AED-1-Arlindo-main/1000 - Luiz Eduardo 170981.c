/*Luiz eduardo garcia de Siqueira 170981 turma NA
AED 1 Prof. Arlindo - 2024.2*/

//main
#include <stdio.h>

int main()
{
    printf("Hello World!\n");

    return 0;
}