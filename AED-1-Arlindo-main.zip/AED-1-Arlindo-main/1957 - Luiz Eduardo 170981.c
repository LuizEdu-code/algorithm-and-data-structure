/*Luiz eduardo garcia de Siqueira 170981 turma NA
AED 1 Prof. Arlindo - 2024.2*/

#include <stdio.h>
#include <stdlib.h>
int main(){ 
	unsigned long int num;
    
    scanf("%ld",&num);
    printf("%lX\n",num); 
return 0;} 
