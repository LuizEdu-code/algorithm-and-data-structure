/*Luiz eduardo garcia de Siqueira 170981 turma NA
AED 1 Prof. Arlindo - 2024.2*/

#include <stdio.h>
int main(){
    char frase[]= "LIFE IS NOT A PROBLEM TO BE SOLVED";
    int i,quantidade;
    scanf("%d",&quantidade);
    frase[quantidade]='\0';
    printf("%s\n",frase);
return 0;}
